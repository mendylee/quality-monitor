module.exports = [
  {
    version: '*',
    examples: {}
  }
]
