var blanket = require("blanket")({
  pattern: require('path').join(__dirname, '../../src')
});

require('./index');